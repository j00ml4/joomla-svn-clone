<?php
/**
 * @package		HelloWorld
 * @license		GNU/GPL, see LICENSE.php
 */

jimport('joomla.application.component.controller');

/**
 * Hello World Component Controller
 *
 * @package		HelloWorld
 */
class HelloController extends JController
{
	/**
	 * Method to display the view
	 *
	 * @access	public
	 */
/*
	function display()
	{
		parent::display();
	}
*/
}
?>
