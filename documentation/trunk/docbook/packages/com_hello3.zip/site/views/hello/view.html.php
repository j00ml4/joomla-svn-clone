<?php
/**
 * Hello View for Hello World Component
 * 
 * @package    Joomla.Tutorials
 * @subpackage Components
 * @link http://dev.joomla.org/component/option,com_jd-wiki/Itemid,31/id,tutorials:modules/
 * @license		GNU/GPL
 */

jimport( 'joomla.application.component.view');

/**
 * HTML View class for the HelloWorld Component
 *
 * @package		Joomla.Tutorials
 * @subpackage	Components
 */
class HelloViewHello extends JView
{
	function display($tpl = null)
	{
		$model =& $this->getModel();
		$greeting = $model->getGreeting();
		$this->assignRef( 'greeting',	$greeting );

		parent::display($tpl);
	}
}
?>
