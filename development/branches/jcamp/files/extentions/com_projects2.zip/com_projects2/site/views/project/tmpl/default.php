<?php
/**
 * @version		$Id: default.php 17059 2010-05-14 16:43:30Z infograf768 $
 * @package		Joomla.Site
 * @subpackage	com_content
 * @copyright	Copyright (C) 2005 - 2010 Open Source Matters, Inc. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */

// no direct access
defined('_JEXEC') or die;
?>

<div class="item-page">

	<h1><?php echo $this->params ?></h1>

	<pre><?php print_r($this); ?></pre>
</div>