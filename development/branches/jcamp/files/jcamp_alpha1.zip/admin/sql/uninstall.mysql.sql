-- -----------------------------------------------------
-- Drop all tables
-- -----------------------------------------------------
DROP TABLE `#__projects`, `#__project_members`, `#__project_contents`, `#__project_tasks`;

