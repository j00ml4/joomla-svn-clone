<?php
/**
 * @version		$Id: media.php 15757 2010-04-01 11:06:27Z infograf768 $
 * @package		Joomla.Site
 * @subpackage	Media
 * @copyright	Copyright (C) 2005 - 2010 Open Source Matters, Inc. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */

/**
 * @package		Joomla.Site
 * @subpackage	com_projects
 */
abstract class ProjectsHelper {  
     /**
     * Method to get list of tasks
     * @param $params JRegistry object with parameters for the output
     * @return List of tasks as an array of objects
     */
    public static function getTasks($params) {
    	$db = JFactory::getDbo();
    	$q = $db->getQuery(true);
    	
    	$q->select('t.title, t.id, t.state');
    	$q->from('`#__project_tasks` AS t');
    	
    	// filter by project id
    	$project_id = (int)$params->get('project.id',0);
    	if($project_id)
	    	$q->where('t.`project_id` = '.$project_id);
	    	
	    // filter by selected filter (state)
	    $filter = $params->get('filter',false);
	    if($filter)
	    	$q->where($filter);
	    
	    // order and limit
	    $ord = $params->get('order.list','t.`ordering`');
	    $start = (int)$params->get('limit.start',0);
	    $limit = (int)$params->get('limit.limit',5);
	    if($ord)
	    	$q->order($ord.' '.$params->get('order.dir','ASC').' LIMIT '.$start.','.$limit);
	    else
	    	$q->order('LIMIT '.$start.','.$limit);

	    $db->setQuery($q);
	    return $db->loadObjectList();
    }
    
     /**
     * Method to get list of documents
     * @param $params JRegistry object with parameters for the output
     * @return List of tasks as an array of objects
     */
    public static function getDocuments($params) {
    	$db = JFactory::getDbo();
    	$q = $db->getQuery(true);
    	
    	$q->select('c.title, c.id');
    	$q->from('`#__project_contents` AS ct');
    	$q->join('left','`#__content` AS c ON c.`id`= ct.`content_id`');
    	
    	// filter by project id
    	$project_id = (int)$params->get('project.id',0);
    	if($project_id)
	    	$q->where('ct.`project_id` = '.$project_id);
	    		    
	    // filter by state
	    $state = $params->get('state',false);
	    if($state !== false)
	    {
	    	if(is_int($state))
				$q->where('c.`state` = '.$state);
			else
				$q->where('c.`state` '.$state);
	    }

		// Filter by access level.
		if ($params->get('filter.access',false)) {
			$user = JFactory::getUser();
			$value = $user->authorisedLevels();
			$q->where('c.access IN ('. implode(',', $value) .')');
		}	

	    // order and limit
	    $ord = $params->get('order.list','c.`modified`, c.`created`');
	    $start = (int)$params->get('limit.start',0);
	    $limit = (int)$params->get('limit.limit',5);
	    if($ord)
	    	$q->order($ord.' '.$params->get('order.dir','ASC').' LIMIT '.$start.','.$limit);
	    else
	    	$q->order('LIMIT '.$start.','.$limit);
	    
	    $db->setQuery($q);
	    
	    return $db->loadObjectList();
    }

     /**
     * Method to get list of members
     * @param $params JRegistry object with parameters for the output
     * @return List of tasks as an array of objects
     */
    public static function getMembers($params) {
    	$db = JFactory::getDbo();
    	$q = $db->getQuery(true);
    	
    	$q->select('u.`name`, u.`id`'); 
    	$q->from('`#__project_members` AS m');
    	$q->join('left','`#__users` AS u ON u.`id`= m.`user_id`');
    	
    	/*
    	$q->select('GROUP_CONCAT(DISTINCT ug.`title` SEPARATOR ", ") AS `role`');
    	$q->join('left','`#__user_usergroup_map` AS ugm ON ugm.`user_id`= u.`id`');
   		$q->join('left','`#__usergroups` AS ug ON ug.`id`= ugm.`group_id`');
    	$q->group('u.id');  	
    	*/
    	
    	// filter by project id
    	$project_id = (int)$params->get('project.id',0);
    	if($project_id){
	    	$q->where('m.`project_id` = '.$project_id);
    	}

    	// order and limit
	    $ord = $params->get('order.list','u.`name`');
	    $start = (int)$params->get('limit.start',0);
	    $limit = (int)$params->get('limit.limit',5);
	    if($ord){
	    	$q->order($ord.' '.$params->get('order.dir','ASC').' LIMIT '.$start.','.$limit);
	    }else{
	    	$q->order('LIMIT '.$start.','.$limit);
	    }
	    $db->setQuery($q);
	    return $db->loadObjectList();
    }
    
    /**
     * Method to get pre-defined links
     * @param $key
     * @param $append
     * 
     * return Routed link
     */
    public static function getLink($key, $append='') {
        static $links;
        if (empty($links)) {
            $links = array(
              'form' => JFilterOutput::ampReplace(JFactory::getURI()->toString()),

            	'portfolios' => 'index.php?option=com_projects&view=portfolios&id=',
              'projects' => 'index.php?option=com_projects&view=projects&id=',
              'project' => 'index.php?option=com_projects&view=project&id=',

            	'members' => 'index.php?option=com_projects&view=members&type=list&id=',
              'members.assign' => 'index.php?option=com_projects&view=members&type=assign&id=',
              'members.unassign' => 'index.php?option=com_projects&view=members&type=delete&id=',
				
            	// we need this coz is more standard
            	'task' => 'index.php?option=com_projects&view=task&type=2&id=',
            	'ticket' => 'index.php?option=com_projects&view=task&type=3&id=',
            	'task.view' => 'index.php?option=com_projects&view=task&id=',
            	'task.edit' => 'index.php?option=com_projects&view=task&layout=edit&id=',

            	'tasks' => 'index.php?option=com_projects&view=tasks&id=',
            	'tasks.task' => 'index.php?option=com_projects&view=tasks&type=2&id=',
            	'tasks.ticket' => 'index.php?option=com_projects&view=tasks&type=3&id=',

            	'documents' => 'index.php?option=com_projects&view=documents&id=',
             	'document' => 'index.php?option=com_projects&view=document&id=',
            	'document.form' => 'index.php?option=com_projects&view=document&layout=edit&id=',
              );
        }
        return JRoute::_($links[strtolower($key)].$append);
    }
    
    /**
     * Method to get a translated text of a importance of a task
     * @param $importance
     * return Translated text of a importance of a task
     */
    public static function getImportanceTask($importance) {
        static $importances;
        if (empty($importances)) {
            $importances = array(
    			1 => 'COM_PROJECTS_PRIORITY_HIGH',
				2 => 'COM_PROJECTS_PRIORITY_NORMAL',
				3 => 'COM_PROJECTS_PRIORITY_LOW',
			);
        }
        return JText::_($importances[$importance]);
	}
	
	/**
	 * Method to trigger all necessary events on content (assumes that real text is in variabla $item->description)
	 * 
	 * @param $item  Item to trigger event on
	 * @return Item with changed "description" property after triggering all events
	 */
	public static function triggerContentEvents(&$item, &$params, $offset=0) {
		$dispatcher	= JDispatcher::getInstance();
		JPluginHelper::importPlugin('content');
		$results = $dispatcher->trigger('onContentPrepare', array ('com_content.article', &$item, &$params, $offset));
		
		// Canot be commented coz bugs document view
		$item->event = new stdClass();
		$results = $dispatcher->trigger('onContentAfterTitle', array('com_content.article', &$item, &$params, $offset));
		$item->event->afterDisplayTitle = trim(implode("\n", $results));

		$results = $dispatcher->trigger('onContentBeforeDisplay', array('com_content.article', &$item, &$params, $offset));
		$item->event->beforeDisplayContent = trim(implode("\n", $results));

		$results = $dispatcher->trigger('onContentAfterDisplay', array('com_content.article', &$item, &$params, $offset));
		$item->event->afterDisplayContent = trim(implode("\n", $results));	
	}

	/**
	 * Method to generate string for db query to get items corresponding to the filter
	 * 
	 * @param $state  Filter
	 * @param $type   Type of the task (ticket/task)
	 * @param $prefix Prefix used for table with tasks (default is t)
	 * @return String for db query to get the right items for this filter
	 */
	public static function getFilterStateQuery($state, $type, $prefix = 't')
	{
		if($type == 3) // tickets
		{
			switch($state)
			{
				case -3: // reported
				case 2 : // finished
				case -2 : // denied
				case 1 : // approved
					return $prefix.'.`type` = 3 AND '.$prefix.'.`state` = '.$state;
				case 0: // all (reported+approved+finished)
					return $prefix.'.`type` = 3 AND '.$prefix.'.`state` IN (1,2,-3)';
				case 4 : // active
					return $prefix.'.`type` = 3 AND '.$prefix.'.`state` IN (-3,1)';
			}
		}
		else // tasks
		{
			switch($state)
			{
				case -3: // reported
				case 2 : // finished
				case -2 : // denied
					return $prefix.'.`type` =2 AND '.$prefix.'.`state` = '.$state;
				case 1 : // pending
					return $prefix.'.`type` IN (2,3) AND '.$prefix.'.`state` = 1';
				case 0: // all (reported+approved+finished)
					return '('.$prefix.'.`type` = 2 AND '.$prefix.'.`state` IN (1,2)) OR ('.$prefix.'.`type`=3 AND '.$prefix.'.`state`=1)';
				case 4 : // pending
					return $prefix.'.`type` IN (2,3) AND '.$prefix.'.`state` = 1';
			}
		}
	}
	
}

?>
