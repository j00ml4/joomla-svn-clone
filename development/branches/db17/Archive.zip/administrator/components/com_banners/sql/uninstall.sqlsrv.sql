DROP TABLE #__banners;

DROP TABLE #__banner_clients;

DROP TABLE #__banner_tracks;
