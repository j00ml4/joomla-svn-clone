DROP TABLE #__contact_details;
